# School Digital Campus System

Uttar Buniyadi Ashram Shala - Digital Campus System
(A Node.js + Express + SQLite application)

## Deploy
This repo is set up for one-click deploy on **Render.com**:
  New -> Blueprint -> select this repo -> Apply
`render.yaml` contains all the settings.

Also works on Railway (railway.json) and Heroku (Procfile).

## Run locally
  npm install
  npm run build
  npm start
  open http://localhost:3000

## Logins
  Student Std 9  : roll 1-80 / student9
  Student Std 10 : roll 1-80 / student10
  Teacher        : registered mobile / teacher (changeable in-app)

## Note about data
Free hosting uses temporary storage, so data resets when the
server restarts. For permanent data, add a disk and set
DCS_DATA_DIR (see comments in render.yaml).
